const express = require("express");
const mongoose = require("mongoose");
const app = express();
const bodyparser = require("body-parser");
const socketIO = require("socket.io");
mongoose.connect("mongodb://localhost:27017/VotingSystem").then(() => console.log("MongoDB Connected")).catch((err) => console.log(err));
app.use(express.static(__dirname));
app.use(bodyparser.urlencoded({extended: true}));
const server = app.listen(8000,()=>{
    console.log("Listening Server at 8000");
});
const io = socketIO(server);

const schema = new mongoose.Schema(
    {
        FirstName: {
            type: String
        },
        LastName: {
            type: String
        },
        Gender: {
            type: String
        },
        VoterID: {
            type: String
        },
        Email: {
            type: String,
            unique: true
        },
        UserName: {
            type: String,
            unique: true
        },
        Password: {
            type: String
        },
        Address: {
            type: String
        },
        Constituency: {
            type: String
        },
        State: {
            type: String
        },
        Pincode: {
            type: String
        },
    }
);
const voter = mongoose.model("Voters", schema);
app.get("/", (req, res) => {
    res.sendFile("Signup.html", {root: "./"});
});
app.post("/", async (req, res) => {
    console.log("Added: ", JSON.stringify(req.body));
    const result = await voter.create({
        FirstName: req.body.FirstName,
        LastName: req.body.LastName,
        Gender: req.body.Gender,
        VoterID: req.body.VoterID,
        Email: req.body.email,
        UserName: req.body.UserName,
        Password: req.body.Password,
        Address: req.body.Address,
        Constituency: req.body.Constituency,
        State: req.body.State,
        Pincode: req.body.PinCode
    });
    res.redirect("/login");
});
app.get("/login",(req,res)=>{
   res.sendFile("loginpage.html",{root:"./"});
});
app.get("/update",(req,res)=>{
    res.sendFile("ForgotPassword.html",{root:"./"});
});
io.on("connection",(socket)=> {
    socket.on("PassChange", async (data) => {
        const email = data.email;
        const pass = data.pass;

        const result = await voter.updateOne({Email: `${email}`}, {$set: {Password: `${pass}`}})
        if (result.modifiedCount === 1) {
            socket.emit("PassResponse","Password Changed");
        } else {
            const demo =  await voter.findOne({Email:email});
            if(demo && demo.Password === pass){
                socket.emit("PassResponse","Password is Same as Previous");
            }
            else {
                socket.emit("PassResponse", "User not found");
            }
        }
    });
});